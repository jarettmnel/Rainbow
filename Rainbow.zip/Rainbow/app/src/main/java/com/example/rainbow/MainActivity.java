package com.example.rainbow;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;

public class MainActivity extends AppCompatActivity {

    Button       buttonRed;
    Button       buttonOrange;
    Button       buttonYellow;
    Button       buttonGreen;
    Button       buttonBlue;
    Button       buttonPurple;
    Button       buttonBlack;
    Button       buttonWhite;
    LinearLayout backgroundLayout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        buttonWhite = findViewById(R.id.button_white);
        buttonWhite.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("White", "The other meat");
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorWhite));
            }
        });
        buttonBlack = findViewById(R.id.button_black);
        buttonBlack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Black", "Not even close to orange");
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorBlack));
            }
        });
        buttonPurple = findViewById(R.id.button_purple);
        buttonPurple.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Purple", "Some joke about rain");
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorPurple));
            }
        });
        buttonBlue = findViewById(R.id.button_blue);
        buttonBlue.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Blue", "Daba dee Daba die");
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorBlue));
            }
        });
        buttonGreen = findViewById(R.id.button_green);
        buttonGreen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Green", "It ain't easy");
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorGreen));
            }
        });
        buttonYellow = findViewById(R.id.button_yellow);
        buttonYellow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Yellow", "Stop yellowing at me");
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorYellow));

            }
        });
        backgroundLayout = findViewById(R.id.background_layout);
        buttonOrange = findViewById(R.id.button_orange);
        buttonOrange.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Orange", "Didn't say banana");
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorOrange));
            }
        });
        buttonRed = findViewById(R.id.button_red);
        buttonRed.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Log.i("Red", "I am angry");
                backgroundLayout.setBackgroundColor(getResources().getColor(R.color.colorRed));
            }
        });
    }
}
